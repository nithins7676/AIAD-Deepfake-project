document.addEventListener('DOMContentLoaded', () => {
    const dropArea = document.getElementById('drop-area');
    const previewImage = document.getElementById('preview-image');
    const analyzeButton = document.getElementById('analyze-button');
    const analysisResult = document.getElementById('analysis-result');
    const resultText = document.getElementById('result-text');
    const confidenceScore = document.getElementById('confidence-score');
    const explanation = document.getElementById('explanation');

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight drop zone when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });

    // Handle dropped files
    dropArea.addEventListener('drop', handleDrop, false);

    // Handle analyze button click
    analyzeButton.addEventListener('click', handleAnalyze, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight(e) {
        dropArea.classList.add('dragover');
    }

    function unhighlight(e) {
        dropArea.classList.remove('dragover');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0 && files[0].type.startsWith('image/')) {
            const file = files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                previewImage.src = e.target.result;
                previewImage.style.display = 'block';
                dropArea.style.display = 'none';
                analyzeButton.style.display = 'block';
            };

            reader.readAsDataURL(file);
        } else {
            alert('Please drop an image file.');
        }
    }

    async function handleAnalyze() {
        analyzeButton.disabled = true;
        analyzeButton.textContent = 'Analyzing...';
        
        try {
            // In a real implementation, this would be an actual API call
            const response = await simulateApiCall(previewImage.src);
            
            // Display results
            resultText.textContent = response.result;
            confidenceScore.textContent = `Confidence: ${response.confidence_score}`;
            explanation.textContent = response.explanation;
            
            // Show analysis result and hide other elements
            analysisResult.style.display = 'block';
            previewImage.style.display = 'none';
            analyzeButton.style.display = 'none';
        } catch (error) {
            console.error('Analysis failed:', error);
            resultText.textContent = 'Analysis failed. Please try again.';
            analysisResult.style.display = 'block';
            analyzeButton.disabled = false;
            analyzeButton.textContent = 'Analyze';
        }
    }

    // Simulate API call
    function simulateApiCall(imageData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    result: "Potentially Fake",
                    confidence_score: 0.92,
                    explanation: "Detected inconsistencies in facial features."
                });
            }, 1500); // Simulate network delay
        });
    }
}); 